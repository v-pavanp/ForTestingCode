var http = require('http'),
    fs = require('fs');

fs.readFile('./View/02-02-timer.html', function (err, html) {
    if (err) {
        throw err; 
    }
    //Console.write(html);
           
    http.createServer(function(request, response) {  
        response.writeHeader(200, {"Content-Type": "text/html"});  
        response.write(html);  
        response.end();  
    }).listen(8000);
});


// var invokeHtml = function InvoeHtml(filename) {
//     window.location.href = "Default.html";
// }
// invokeHtml("Default.html");
